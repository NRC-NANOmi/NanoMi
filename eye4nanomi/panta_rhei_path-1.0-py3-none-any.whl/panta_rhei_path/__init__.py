import sys
from .find_path import find_path

try:
    import panta_rhei
except ImportError:
    pr_path = find_path()
    if pr_path is not None:
        sys.path.append(pr_path)
