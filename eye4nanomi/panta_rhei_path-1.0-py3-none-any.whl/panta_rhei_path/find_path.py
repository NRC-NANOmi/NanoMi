import sys
from os import path
from glob import glob

from .default_names import default_pattern, default_root

# alternatively, find path to some executable with shutils.which and
# then get python search path from this path. Check with Win10 ... 

def find_path(pattern=default_pattern , root=default_root):
    roots = []
    for p in pattern:
        roots.extend(glob(path.join(root, p)))
        
    if len(roots) > 1:
        print("PantaRhei: Found more then one possible environment:")
        for r in roots:
            print("           {}". format(r))
        # take the shortes root since sometime old installations are moved away
        # by appending some text at the end like '_orig' or '_old'        
        pr_path = path.join(sorted(roots, key=len)[0], 'lib')    
        print("PantaRhei: Adding {} to search path.".format(pr_path))
    elif len(roots)==1:
        print("PantaRhei: Found eaxctly one possible environment:")
        print("         {}". format(roots[0]))
        pr_path = path.join(roots[0], 'lib')    
        print("PantaRhei: Adding {} to search path.".format(pr_path))
    else:
        pr_path = None      
        print("PantaRhei: No custom installation found, using default search path.")
    return pr_path      
