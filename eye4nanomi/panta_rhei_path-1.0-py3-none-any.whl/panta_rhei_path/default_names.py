default_pattern = [r'CEOS Panta Rhei *', r'CEOS Filter Control *'] 
default_root = r"C:\Program Files"
