from .default_names import default_root, default_pattern
from .find_path import find_path

if __name__ == '__main__':

    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default=default_root)
    parser.add_argument('--pattern', nargs='+', default=default_pattern)
    args = parser.parse_args()
    
    find_path(root=args.root, pattern=args.pattern)
